var app = new Vue({
  el: '#generator',
  data: {
    ms: '1', // MS
    stack: '1', // 環境
    secret: '0', // 
    env_var: 'key_name', // 環境変数名
    value: 'value', // 値

    mapkey: 'KeyName',
    cfn_ms: 'AccountMS',
    cfn_stack: 'CICID-MpTestForMintaku',
    cfn_envkey: 'KEY_NAME',
    cfn_envtype: 'PLAINTEXT',
    buildspec: 'CONFIGMAP',
    development_ms: 'account',
    development_ref: 'configMapKeyRef',
    development_values_path: 'configmap',
    development_env: 'env'
  }
});

app.$watch('ms', function (newValue, oldValue) {
   setMs(newValue)
})
app.$watch('stack', function (newValue, oldValue) {
   setStackName(newValue)
})
app.$watch('env_var', function (newValue, oldValue) {
  app.$data.cfn_envkey = app.$data.env_var
  app.$data.cfn_envkey = convertEnvKey(app.$data.cfn_envkey)

  app.$data.mapkey = app.$data.env_var
  app.$data.mapkey = convertMappingsKey(app.$data.mapkey)
})
app.$watch('secret', function (newValue, oldValue) {
  setType(newValue)
})

/*
*  入力された環境変数名からCfnのCodebuildの環境変数キー名を作成する
*  引数：環境変数名
*  戻り値：CfnのCodebuildの環境変数キー名
*/
function convertEnvKey(str){
    // 小文字に変換
    str = str.replace(/([a-z])/g, function(val) {
            return val.toUpperCase();
        }
    );
    //-を_に変換
    return str.replace( '-', '_' );
};

/*
*  入力された環境変数名からCfnのMappingのキー名を作成する
*  引数：環境変数名
*  戻り値：CfnのMappingのキー名を作成する
*/
function convertMappingsKey(str){
    // 大文字に変換
    str = str.replace(/([A-Z])/g, function(val) {
            return val.charAt(0).toLowerCase();
        }
    );
    // 先頭を大文字にする
    str = str.replace(/^[a-z]/g, function(val) {
            return val.toUpperCase();
        }
    );
    //_+小文字を大文字にする(例:_a を A)
    str = str.replace(/_./g, function(val) {
            return val.charAt(1).toUpperCase();
        }
    );
    //-+小文字を大文字にする(例:-a を A)
    return str.replace(/-./g, function(val) {
            return val.charAt(1).toUpperCase();
        }
    );
};

/*
*  MS選択リストからMS名を設定する
*  引数：MS選択リストの値
*  戻り値：なし
*/
function setMs(value) {
  switch( value ) {
    case "1":
      app.$data.cfn_ms = 'AccountMS'
      app.$data.development_ms = 'account'
      break;
    case "2":
      app.$data.cfn_ms = 'CycleMS'
      app.$data.development_ms = 'cycle'
      break;
    case "3":
      app.$data.cfn_ms = 'KeyCloakPluginMS'
      app.$data.development_ms = 'keycloak'
      break;
    case "4":
      app.$data.cfn_ms = 'MasterDataMS'
      app.$data.development_ms = 'masterdata'
      break;
    case "5":
      app.$data.cfn_ms = 'MpOrchestrationMS'
      app.$data.development_ms = 'mporchestration'
      break;
    case "6":
      app.$data.cfn_ms = 'NotificationMS'
      app.$data.development_ms = 'notification'
      break;
    case "7":
      app.$data.cfn_ms = 'OpeOrchestrationMS'
      app.$data.development_ms = 'opeorchestration'
      break;
    case "8":
      app.$data.cfn_ms = 'OrchestrationMS'
      app.$data.development_ms = 'orchestration'
      break;
    case "9":
      app.$data.cfn_ms = 'PaymentMS'
      app.$data.development_ms = 'payment'
      break;
    case "10":
      app.$data.cfn_ms = 'SuicaMS'
      app.$data.development_ms = 'suica'
      break;
    case "11":
      app.$data.cfn_ms = 'TaxiMS'
      app.$data.development_ms = 'taxi'
      break;
    case "12":
      app.$data.cfn_ms = 'UsageHistoryMS'
      app.$data.development_ms = 'usagehistory'
      break;
  }
}

/*
*  環境選択リストからCfnスタック名を設定する
*  引数：環境選択リストの値
*  戻り値：なし
*/
function setStackName(value) {
  switch( value ) {
    case "1":
      app.$data.cfn_stack = 'CICID-MpTestForMintaku'
      break;
    case "2":
      app.$data.cfn_stack = 'CICID-MpTestForTlb'
      break;
    case "3":
      app.$data.cfn_stack = 'CICD-MpTestForG3m'
      break;
    case "4":
      app.$data.cfn_stack = 'CICD-Stg01ForDev'
      break;
    case "5":
      app.$data.cfn_stack = 'CICD-Staging'
      break;
    case "6":
      app.$data.cfn_stack = 'CICD-Prod'
      break;
  }
}

/*
*  秘匿情報選択リストからconfigmap/secretを設定する
*  引数：秘匿情報選択リストの値
*  戻り値：なし
*/
function setType(value) {
   if (value === "0") {
       app.$data.cfn_envtype = 'PLAINTEXT'
       app.$data.buildspec = 'CONFIGMAP'
       app.$data.development_ref = 'configMapKeyRef'
       app.$data.development_values_path = 'configmap'
       app.$data.development_env = 'env'
   } else {
       app.$data.cfn_envtype = 'PARAMETER_STORE'
       app.$data.buildspec = 'SECRETS'
       app.$data.development_ref = 'secretKeyRef'
       app.$data.development_values_path = 'secret'
       app.$data.development_env = 'secrets'
   }
}
