var app = new Vue({
  el: '#generator',
  data: {
    ms: '0', // MS
    env: '0', // 環境

    codebuild_ms: '',
    codebuild_env: '',
    tmpdata: [],
    codebuild_projects: []
  },
  created() {
    // AWS認証情報
    AWS.config.update({
      credentials: new AWS.Credentials(
        "", // クレデンシャルID
        "" // パスワード
      ),
      region: "ap-northeast-1"
    });
  },
  mounted() {
    searchProects()
  }
});

app.$watch('ms', function (newValue, oldValue) {
   setMs(newValue)
   searchProects()
})
app.$watch('env', function (newValue, oldValue) {
   setEnv(newValue)
   searchProects()
})

function searchProects() {
  const codebuild = new AWS.CodeBuild();
  
  // CodeBuildから全てのプロジェクトを取得して検索
  var params = {
    sortBy: 'NAME',
    sortOrder: 'ASCENDING'
  };
  codebuild.listProjects(params, function(err, data) {
    if (err) {
        console.log(err, err.stack);  // an error occurred
    } else {
        for (var i = 0, len = data.projects.length; i < len; ++i) {
            var pj = data.projects[i];
            console.log(app.$data.codebuild_env, app.$data.codebuild_ms)
//            if (pj.indexOf('deploy') !== -1 &&
//                pj.indexOf(app.$data.codebuild_env) !== -1 &&
//                pj.indexOf(app.$data.codebuild_ms) !== -1) {
                app.$data.tmpdata.push(pj);
//            }
        }
    }
  });

  // 各プロジェクトの環境変数情報取得
  var params = {
    names: app.$data.tmpdata
  };
  codebuild.batchGetProjects(params, function(err, data) {
    if (err) {
      console.log(err, err.stack);  // an error occurred
    } else {
      app.$data.codebuild_projects = data.projects;
    }
  });
}

/*
*  MS選択リストからビルドプロジェクト名を設定する
*  引数：MS選択リストの値
*  戻り値：なし
*/
function setMs(value) {
  switch( value ) {
    case "0":
      app.$data.codebuild_ms = ''
      break;
    case "1":
      app.$data.codebuild_ms = 'Account'
      break;
    case "2":
      app.$data.codebuild_ms = 'Cycle'
      break;
    case "3":
      app.$data.codebuild_ms = 'KeyCloakPlugin'
      break;
    case "4":
      app.$data.codebuild_ms = 'MasterData'
      break;
    case "5":
      app.$data.codebuild_ms = 'MpOrchestration'
      break;
    case "6":
      app.$data.codebuild_ms = 'Notification'
      break;
    case "7":
      app.$data.codebuild_ms = 'OpeOrchestration'
      break;
    case "8":
      app.$data.codebuild_ms = 'Orchestration'
      break;
    case "9":
      app.$data.codebuild_ms = 'Payment'
      break;
    case "10":
      app.$data.codebuild_ms = 'Suica'
      break;
    case "11":
      app.$data.codebuild_ms = 'Taxi'
      break;
    case "12":
      app.$data.codebuild_ms = 'UsageHistory'
      break;
  }
}

/*
*  環境選択リストからビルドプロジェクト名を設定する
*  引数：環境選択リストの値
*  戻り値：なし
*/
function setEnv(value) {
  switch( value ) {
    case "0":
      app.$data.codebuild_env = ''
      break;
    case "1":
      app.$data.codebuild_env = 'Min'
      break;
    case "2":
      app.$data.codebuild_env = 'Tlb'
      break;
    case "3":
      app.$data.codebuild_env = 'G3m'
      break;
    case "4":
      app.$data.codebuild_env = 'Stg01'
      break;
//    case "5":
//      app.$data.codebuild_env = 'Staging'
//      break;
//    case "6":
//      app.$data.codebuild_env = 'Prod'
//      break;
  }
}
