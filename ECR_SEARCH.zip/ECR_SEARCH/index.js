var app = new Vue({
  el: '#generator',
  data: {
    imageDetails: [],
    columns: [
      {
        label: 'リポジトリ名',
        field: 'repositoryName',
        width: '10px',
        filterOptions: {
            enabled: true,
        }
      },
      {
        label: 'Imageタグ',
        field: 'imageTags',
        width: '500px',
        filterOptions: {
            enabled: true,
        }
      },
      {
        label: 'イメージURI',
        field: 'imageDigest',
        width: '500px',
        filterOptions: {
            enabled: true,
        }
      },
      {
        label: '更新日時',
        field: 'imagePushedAt',
        width: '500px',
      },
    ]
    
  },
  created() {
    // AWS認証情報
    AWS.config.update({
      credentials: new AWS.Credentials(
        "", // クレデンシャルID
        "" // パスワード
      ),
      region: "ap-northeast-1"
    });
  },
  methods: {
    window:onload = function() {  
      getImages();
    },
  }
});

async function getImages() {
try {
  const ecr = new AWS.ECR();

  var tmp = '';
  // ECRから全情報取得して検索
  var params = {
  };
  const res1 = await ecr.describeRepositories(params).promise();
  for (var i = 0, len = res1.repositories.length; i < len; ++i) {
    var params = {
      repositoryName: res1.repositories[i].repositoryName,
    };
    
    const res2 = await ecr.describeImages(params).promise();
    app.$data.imageDetails = res2.imageDetails;
  };
  } catch(err) {
    console.error(err);
  }
}
